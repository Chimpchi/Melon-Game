public class MelonPool : ObjectPool<Melon> {}
